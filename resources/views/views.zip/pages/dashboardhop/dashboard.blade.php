{{-- Extends layout --}}
@extends('layout.default')

{{-- Content --}}
@section('content')
    {{-- Dashboard 1 --}}

    <div class="panel-grid-supplier">
    <div class="">
							<div class="row">
								<div class="col-lg-4">
									<!--begin::Callout-->
									<div class="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0">
										<div class="card-body">
											<div class="d-flex align-items-center p-5">
												<!--begin::Icon-->
												<div class="mr-6">
													<span class="svg-icon svg-icon-primary svg-icon-4x">
														<!--begin::Svg Icon | path:assets/media/svg/icons/Home/Mirror.svg-->
														<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                <rect x="0" y="0" width="24" height="24"/>
                                                                <path d="M3.95709826,8.41510662 L11.47855,3.81866389 C11.7986624,3.62303967 12.2013376,3.62303967 12.52145,3.81866389 L20.0429,8.41510557 C20.6374094,8.77841684 21,9.42493654 21,10.1216692 L21,19.0000642 C21,20.1046337 20.1045695,21.0000642 19,21.0000642 L4.99998155,21.0000673 C3.89541205,21.0000673 2.99998155,20.1046368 2.99998155,19.0000673 L2.99999828,10.1216672 C2.99999935,9.42493561 3.36258984,8.77841732 3.95709826,8.41510662 Z M10,13 C9.44771525,13 9,13.4477153 9,14 L9,17 C9,17.5522847 9.44771525,18 10,18 L14,18 C14.5522847,18 15,17.5522847 15,17 L15,14 C15,13.4477153 14.5522847,13 14,13 L10,13 Z" fill="#000000"/>
                                                            </g>
                                                        </svg>
														<!--end::Svg Icon-->
													</span>
												</div>
												<!--end::Icon-->
												<!--begin::Content-->
												<div class="d-flex flex-column">
													<a href="#" class="text-dark text-hover-primary font-weight-bold font-size-h4 mb-3">{{$dt['jumlah_vessel']}}</a>
													<div class="text-dark-75">Jumlah Vessel, Tug Boat & Barge </div>
												</div>
												<!--end::Content-->
											</div>
										</div>
									</div>
									<!--end::Callout-->
								</div>
								<div class="col-lg-4">
									<!--begin::Callout-->
									<div class="card card-custom wave wave-animate-slow wave-danger mb-8 mb-lg-0">
										<div class="card-body">
											<div class="d-flex align-items-center p-5">
												<!--begin::Icon-->
												<div class="mr-6">
													<span class="svg-icon svg-icon-danger svg-icon-4x">
														<!--begin::Svg Icon | path:assets/media/svg/icons/General/Thunder-move.svg-->
														<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
															<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																<rect x="0" y="0" width="24" height="24" />
																<path d="M16.3740377,19.9389434 L22.2226499,11.1660251 C22.4524142,10.8213786 22.3592838,10.3557266 22.0146373,10.1259623 C21.8914367,10.0438285 21.7466809,10 21.5986122,10 L17,10 L17,4.47708173 C17,4.06286817 16.6642136,3.72708173 16.25,3.72708173 C15.9992351,3.72708173 15.7650616,3.85240758 15.6259623,4.06105658 L9.7773501,12.8339749 C9.54758575,13.1786214 9.64071616,13.6442734 9.98536267,13.8740377 C10.1085633,13.9561715 10.2533191,14 10.4013878,14 L15,14 L15,19.5229183 C15,19.9371318 15.3357864,20.2729183 15.75,20.2729183 C16.0007649,20.2729183 16.2349384,20.1475924 16.3740377,19.9389434 Z" fill="#000000" />
																<path d="M4.5,5 L9.5,5 C10.3284271,5 11,5.67157288 11,6.5 C11,7.32842712 10.3284271,8 9.5,8 L4.5,8 C3.67157288,8 3,7.32842712 3,6.5 C3,5.67157288 3.67157288,5 4.5,5 Z M4.5,17 L9.5,17 C10.3284271,17 11,17.6715729 11,18.5 C11,19.3284271 10.3284271,20 9.5,20 L4.5,20 C3.67157288,20 3,19.3284271 3,18.5 C3,17.6715729 3.67157288,17 4.5,17 Z M2.5,11 L6.5,11 C7.32842712,11 8,11.6715729 8,12.5 C8,13.3284271 7.32842712,14 6.5,14 L2.5,14 C1.67157288,14 1,13.3284271 1,12.5 C1,11.6715729 1.67157288,11 2.5,11 Z" fill="#000000" opacity="0.3" />
															</g>
														</svg>
														<!--end::Svg Icon-->
													</span>
                                                  
												</div>
												<!--end::Icon-->
												<!--begin::Content-->
												<div class="d-flex flex-column">
													<a href="#" class="text-dark text-hover-primary font-weight-bold font-size-h4 mb-3">{{$dt['jumlah_unit_pembangkit']}}</a>
													<div class="text-dark-75">Jumlah Unit Pembangkit</div>
												</div>
												<!--end::Content-->
											</div>
										</div>
									</div>
									<!--end::Callout-->
								</div>
								<div class="col-lg-4">
									<!--begin::Callout-->
									<div class="card card-custom wave wave-animate-slow wave-success mb-8 mb-lg-0">
										<div class="card-body">
											<div class="d-flex align-items-center p-5">
												<!--begin::Icon-->
												<div class="mr-6">
													<span class="svg-icon svg-icon-success svg-icon-4x">
														<!--begin::Svg Icon | path:assets/media/svg/icons/Design/Sketch.svg-->
														<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                <rect x="0" y="0" width="24" height="24"/>
                                                                <path d="M8,4 C8.55228475,4 9,4.44771525 9,5 L9,17 L18,17 C18.5522847,17 19,17.4477153 19,18 C19,18.5522847 18.5522847,19 18,19 L9,19 C8.44771525,19 8,18.5522847 8,18 C7.44771525,18 7,17.5522847 7,17 L7,6 L5,6 C4.44771525,6 4,5.55228475 4,5 C4,4.44771525 4.44771525,4 5,4 L8,4 Z" fill="#000000" opacity="0.3"/>
                                                                <rect fill="#000000" opacity="0.3" x="11" y="7" width="8" height="8" rx="4"/>
                                                                <circle fill="#000000" cx="8" cy="18" r="3"/>
                                                            </g>
                                                        </svg>
														<!--end::Svg Icon-->
													</span>
												</div>
												<!--end::Icon-->
												<!--begin::Content-->
												<div class="d-flex flex-column">
													<a href="#" class="text-dark text-hover-primary font-weight-bold font-size-h4 mb-3">{{$dt['jumlah_delivery']}}</a>
													<div class="text-dark-75">On Going Delivery</div>
												</div>
												<!--end::Content-->
											</div>
										</div>
									</div>
									<!--end::Callout-->
								</div>
							</div>
						</div>
						<!--end::Section-->
       
        <br>
        <div class="row">      
        <div class="separator separator-dashed separator-border-2"></div>
            <div class="col-lg-3">
                <!--begin::Stats Widget 32-->
                    <div class="box-br" style="background-color:#E9EF47">
                    <!--begin::Body-->
                    <div class="card-body">
                        <span class="font-weight-bold font-weight-bolder font-size-h4">BB JAMALI</span>
                        <span class="card-title font-weight-bolder font-size-lg mb-0 mt-6 text-hover-primary d-block total_trx">Ren : {{$dt['rencana_jamali']}} &nbsp; | &nbsp; Real : {{$dt['realisasi_jamali']}}</span>
                        <span class="font-weight-bold font-size-sm">Last update at : {{$dt['latest_jamali']}}</span>
                    </div>
                    <!--end::Body-->
                </div>
                <!--end::Stats Widget 32-->
            </div>
            <div class="col-lg-3">
                <!--begin::Stats Widget 32-->
                    <div class="box-br" style="background-color:#E9EF47">
                    <!--begin::Body-->
                    <div class="card-body">
                        <span class="font-weight-bold font-weight-bolder font-size-h4">BB SUMKAL</span>
                        <span class="card-title font-weight-bolder font-size-lg mb-0 mt-6 text-hover-primary d-block total_trx">Ren : {{$dt['rencana_sumkal']}} &nbsp; | &nbsp; Real : {{$dt['realisasi_sumkal']}}</span>
                        <span class="font-weight-bold font-size-sm">Last update at : {{$dt['latest_sumkal']}}</span>
                    </div>
                    <!--end::Body-->
                </div>
                <!--end::Stats Widget 32-->
            </div>

            <div class="col-lg-3">
                <!--begin::Stats Widget 32-->
                    <div class="box-br" style="background-color:#E9EF47">
                    <!--begin::Body-->
                    <div class="card-body">
                        <span class="font-weight-bold font-weight-bolder font-size-h4">BB SULMAPA</span>
                        <span class="card-title font-weight-bolder font-size-lg mb-0 mt-6 text-hover-primary d-block total_trx">Ren : {{$dt['rencana_sulmapa']}} &nbsp; | &nbsp; Real : {{$dt['realisasi_sulmapa']}}</span>
                        <span class="font-weight-bold font-size-sm">Last update at : {{$dt['latest_sulmapa']}}</span>
                    </div>
                    <!--end::Body-->
                </div>
                <!--end::Stats Widget 32-->
            </div>

            <div class="col-lg-3">
                <!--begin::Stats Widget 32-->
                    <div class="box-br" style="background-color:#E9EF47">
                    <!--begin::Body-->
                    <div class="card-body">
                        <span class="font-weight-bold font-weight-bolder font-size-h4">BIOMASA</span>
                        <span class="card-title font-weight-bolder font-size-lg mb-0 mt-6 text-hover-primary d-block total_trx">Ren : {{$dt['rencana_biomasa']}} &nbsp; | &nbsp; Real : {{$dt['realisasi_biomasa']}}</span>
                        <span class="font-weight-bold font-size-sm">Last update at : {{$dt['latest_biomasa']}}</span>
                    </div>
                    <!--end::Body-->
                </div>
                <!--end::Stats Widget 32-->
            </div>

            <div class="col-lg-3 mt-6">
                <!--begin::Stats Widget 32-->
                    <div class="box-br" style="background-color:#E9EF47">
                    <!--begin::Body-->
                    <div class="card-body">
                        <span class="font-weight-bold font-weight-bolder font-size-h4">GAS PIPA</span>
                        <span class="card-title font-weight-bolder font-size-lg mb-0 mt-6 text-hover-primary d-block total_trx">Ren : {{$dt['rencana_gaspipa']}} &nbsp; | &nbsp; Real : {{$dt['realisasi_gaspipa']}}</span>
                        <span class="font-weight-bold font-size-sm">Last update at : {{$dt['latest_gaspipa']}}</span>
                    </div>
                    <!--end::Body-->
                </div>
                <!--end::Stats Widget 32-->
            </div>

            <div class="col-lg-3 mt-6">
                <!--begin::Stats Widget 32-->
                    <div class="box-br" style="background-color:#E9EF47">
                    <!--begin::Body-->
                    <div class="card-body">
                        <span class="font-weight-bold font-weight-bolder font-size-h4">LNG</span>
                        <span class="card-title font-weight-bolder font-size-lg mb-0 mt-6 text-hover-primary d-block total_trx">Ren : {{$dt['rencana_lng']}} &nbsp; | &nbsp; Real : {{$dt['realisasi_lng']}}</span>
                        <span class="font-weight-bold font-size-sm">Last update at : {{$dt['latest_lng']}}</span>
                    </div>
                    <!--end::Body-->
                </div>
                <!--end::Stats Widget 32-->
            </div>

            <div class="col-lg-3 mt-6">
                <!--begin::Stats Widget 32-->
                    <div class="box-br" style="background-color:#E9EF47">
                    <!--begin::Body-->
                    <div class="card-body">
                        <span class="font-weight-bold font-weight-bolder font-size-h4">BBM</span>
                        <span class="card-title font-weight-bolder font-size-lg mb-0 mt-6 text-hover-primary d-block total_trx">Ren : {{$dt['rencana_bbm']}} &nbsp; | &nbsp; Real : {{$dt['realisasi_bbm']}}</span>
                        <span class="font-weight-bold font-size-sm">Last update at : {{$dt['latest_bbm']}}</span>
                    </div>
                    <!--end::Body-->
                </div>
                <!--end::Stats Widget 32-->
            </div>
           
        </div>
       


    </div>
@endsection

{{-- Scripts Section --}}
@section('scripts')
    <script src="{{ asset('plugins/custom/datatables/datatables.bundle.js') }}" type="text/javascript"></script>
    <script src="{{ asset('js/pages/widgets.js') }}" type="text/javascript"></script>
    <script src="{{ asset('js/module/dashboard/dashboard.js?random=' . date('ymdHis')) }}" type="text/javascript"></script>
    <script>
        const start_date = "{{ $startDate }}";
        const end_date = "{{ $endDate }}";
    </script>
@endsection
