<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="{{ asset('media/logos/favicon.png') }}" />
    <title>Dashboard</title>
    <link href="{{ asset('dashboard/style.css?random='.date('ymdHis')) }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('dashboard/addon.css?random='.date('ymdHis')) }}" rel="stylesheet" type="text/css" />
  </head>
  <body style="background:#222 url('{{ asset('media/logos/bg3.png') }}'); no-repeat center center;background-size:100% 100%; background-attachment:fixed;">
    <header>
      <marquee >
        <p> @php 
              $ntop=1;
            @endphp
            @foreach($running_text['top'] as $top => $teks)
              <?php
                if($ntop < $running_text['top_count']){
                    $top_sep = "|";
                }else{
                    $top_sep = "";
                }
              ?>

              <span class="p-rt-black">{{$teks}}</span> {{$top_sep}}
              @php 
                $ntop++;
              @endphp
            @endforeach
        </p>
      </marquee>
     
    </header>

    <div class="flex">
      <div class="column">
        <div class="card-title display-mobile">
            <img src="{{ asset('media/logos/plnepi.png') }}" alt="PLNEPI" class="logo-img">
        </div>
        <div class="card-title --dashboard display-mobile">
          <h2>DASHBOARD REALISASI VOLUME (REVOL) <br> <button class="legend-ren">rencana</button> <button class="legend-real">realisasi</button></h2>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container"></div>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-2"></div>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-3"></div>
        </div>
      </div>
      <div class="column">
        <div class="card-title display-mobile">
            <img src="{{ asset('media/logos/plnepi.png') }}" alt="PLNEPI" class="logo-img">
        </div>
        <div class="card-title --dashboard display-mobile">
          <h2>DASHBOARD <br> REALISASI VOLUME <br> (REVOL) <br> <button class="legend-ren">rencana</button> <button class="legend-real">realisasi</button></h2>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-4"></div>
        </div>
        <div class="card-footer display-mobile">
          <h6>
            Weekly Updated
            <br />
            <div class="pt-10">
            Last update
            <br />
            {{$latest_date['latest']}}
            </div>
          </h6>
        </div>
      </div>
      <div class="column">
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-5"></div>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-6"></div>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-7"></div>
        </div>
        <div class="card-footer display-mobile">
          <h6>
            Weekly Updated
            <br />
            <div class="pt-10">
            Last update
            <br />
            {{$latest_date['latest']}}
            </div>
          </h6>
        </div>
      </div>
     
    </div>
    <span class="tuwtext">tuw</span>
    <div class="footertop">
      <marquee behavior="scroll" scrollamount="8">
        <p> 
            @php 
              $nbt=1;
            @endphp
            @foreach($running_text['bottom_top'] as $bt)
            <?php
                if($nbt < $running_text['bottom_top_count']){
                    $bt_sep = "|";
                }else{
                    $bt_sep = "";
                }
              ?>
              <span class="p-rt-black">{{$bt}}</span> {{$bt_sep}}
              @php 
                $nbt++;
              @endphp
            @endforeach
        </p>
      </marquee>
    </div>
    <footer>
      <marquee behavior="scroll" >
        <p> 
            @php 
              $nbot=1;
            @endphp
            @foreach($running_text['bottom'] as $bottom)
            <?php
                if($nbot < $running_text['bottom_count']){
                    $btot_sep = "|";
                }else{
                    $btot_sep = "";
                }
              ?>
              <span class="p-rt-white">{{$bottom}}</span> {{$btot_sep}}
              @php 
                $nbot++;
              @endphp
            @endforeach
        </p>
      </marquee>
    </footer>

    {{-- Scripts Section --}}

    <script>
        const type = "{{$type}}";
    </script>
    <script>var KTAppSettings = { "breakpoints": { "sm": 576, "md": 768, "lg": 992, "xl": 1200, "xxl": 1400 }, "colors": { "theme": { "base": { "white": "#ffffff", "primary": "#3699FF", "secondary": "#E5EAEE", "success": "#1BC5BD", "info": "#8950FC", "warning": "#FFA800", "danger": "#F64E60", "light": "#E4E6EF", "dark": "#181C32" }, "light": { "white": "#ffffff", "primary": "#E1F0FF", "secondary": "#EBEDF3", "success": "#C9F7F5", "info": "#EEE5FF", "warning": "#FFF4DE", "danger": "#FFE2E5", "light": "#F3F6F9", "dark": "#D6D6E0" }, "inverse": { "white": "#ffffff", "primary": "#ffffff", "secondary": "#3F4254", "success": "#ffffff", "info": "#ffffff", "warning": "#ffffff", "danger": "#ffffff", "light": "#464E5F", "dark": "#ffffff" } }, "gray": { "gray-100": "#F3F6F9", "gray-200": "#EBEDF3", "gray-300": "#E4E6EF", "gray-400": "#D1D3E0", "gray-500": "#B5B5C3", "gray-600": "#7E8299", "gray-700": "#5E6278", "gray-800": "#3F4254", "gray-900": "#181C32" } }, "font-family": "Poppins" };</script>
    <script src="{{ asset('plugins/global/plugins.bundle.js') }}"></script>
		<script src="{{ asset('plugins/custom/prismjs/prismjs.bundle.js') }}"></script>
		<script src="{{ asset('js/scripts.bundle.js') }}"></script>
    <script src="https://code.highcharts.com/10/highcharts.js"></script>
    <script src="{{ asset('dashboard/main.js?random='.date('ymdHis')) }}"></script>
    
  
  </body>
</html>
