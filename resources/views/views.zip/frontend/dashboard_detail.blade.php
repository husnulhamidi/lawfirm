<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="{{ asset('media/logos/favicon.png') }}" />
    <title>Dashboard</title>
    <link href="{{ asset('dashboard/style.css') }}" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <header>
      <marquee >
        <p> USD~IDR ... | HBA Rp ... | ICP USD ... | (Status Vessel) MV Kartini Baruna : Good</p>
      </marquee>
      <!-- <div>
        <p>(Status Vessel) MV Kartini Baruna : Good</p>
      </div> -->
    </header>

    <div class="flex">
      <div class="column">
        <div class="card-title display-mobile">
            <div class="img-logo">
                <img src="{{ asset('media/logos/plnepi.png') }}" class="max-h-100px" alt="" width="150px"/>
            </div>
        </div>
        <div class="card-title --dashboard display-mobile">
          <h2>DASHBOARD REALISASI VOLUME (REVOL)</h2>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container"></div>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-2"></div>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-3"></div>
        </div>
      </div>
      <div class="column">
        <div class="card-title display-mobile">
            <div class="img-logo">
                <img src="{{ asset('media/logos/plnepi.png') }}" class="max-h-100px" alt="" width="150px"/>
            </div>
        </div>
        <div class="card-title --dashboard display-mobile">
          <h2>DASHBOARD <br> REALISASI VOLUME <br> (REVOL)</h2>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-4"></div>
        </div>
        <div class="card-footer display-mobile">
          <h6>
            Weekly Update
            <br />
            Last updated
            <br />
            29 April 2024
          </h6>
        </div>
      </div>
      <div class="column">
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-5"></div>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-6"></div>
        </div>
        <div class="card-hexa">
          <div class="custom-highchart" id="chart-container-7"></div>
        </div>
        <div class="card-footer display-mobile">
          <h6>
            Weekly Update
            <br />
            Last updated
            <br />
            29 April 2024
          </h6>
        </div>
      </div>
    </div>

    <footer>
      <marquee behavior="scroll">
        <p>Delivery Plan</p>
      </marquee>
    </footer>
    <script>var KTAppSettings = { "breakpoints": { "sm": 576, "md": 768, "lg": 992, "xl": 1200, "xxl": 1400 }, "colors": { "theme": { "base": { "white": "#ffffff", "primary": "#3699FF", "secondary": "#E5EAEE", "success": "#1BC5BD", "info": "#8950FC", "warning": "#FFA800", "danger": "#F64E60", "light": "#E4E6EF", "dark": "#181C32" }, "light": { "white": "#ffffff", "primary": "#E1F0FF", "secondary": "#EBEDF3", "success": "#C9F7F5", "info": "#EEE5FF", "warning": "#FFF4DE", "danger": "#FFE2E5", "light": "#F3F6F9", "dark": "#D6D6E0" }, "inverse": { "white": "#ffffff", "primary": "#ffffff", "secondary": "#3F4254", "success": "#ffffff", "info": "#ffffff", "warning": "#ffffff", "danger": "#ffffff", "light": "#464E5F", "dark": "#ffffff" } }, "gray": { "gray-100": "#F3F6F9", "gray-200": "#EBEDF3", "gray-300": "#E4E6EF", "gray-400": "#D1D3E0", "gray-500": "#B5B5C3", "gray-600": "#7E8299", "gray-700": "#5E6278", "gray-800": "#3F4254", "gray-900": "#181C32" } }, "font-family": "Poppins" };</script>
    <script src="https://code.highcharts.com/10/highcharts.js"></script>
    <script src="{{ asset('plugins/global/plugins.bundle.js') }}"></script>
		<script src="{{ asset('plugins/custom/prismjs/prismjs.bundle.js') }}"></script>
		<script src="{{ asset('js/scripts.bundle.js') }}"></script>
    <script src="{{ asset('dashboard/main.js') }}"></script>
   
  </body>
</html>
