
<!DOCTYPE html>

<html lang="en">
	<!--begin::Head-->
	<head>
		<meta charset="utf-8" />
		<title>Scheduler</title>
        <meta name="csrf-token" content="{{ csrf_token() }}">
		<meta name="description" content="Scheduler P2EP" />
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
		<!-- <link rel="shortcut icon" href="{{ asset('media/logos/p2ep.png') }}" /> -->
		
        <link href="{{ asset ('css/styleuc.css') }}" rel="stylesheet" type="text/css" />
		
	</head>
	<!--end::Head-->
	<!--begin::Body-->
	<body id="kt_body"  style="background:#222 url('{{ asset('media/logos/contruction.jpg') }}');no-repeat center center;background-size:cover; background-attachment:fixed; ">
        <div class="container">
            
            <div class="">
                <img alt="Logo" src="{{ asset('media/logos/contruction_.jpg') }}" width="70%"/>
            </div>
        </div>
        
	</body>
	<!--end::Body-->
</html>
