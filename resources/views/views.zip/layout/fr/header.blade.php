<!--begin::Header-->
<div id="kt_header" class="header header-fixed">
						<!--begin::Container-->
						<div class="container-fluid d-flex align-items-stretch justify-content-between">
							<!--begin::Header Menu Wrapper-->
							<div class="header-menu-wrapper header-menu-wrapper-left" id="kt_header_menu_wrapper">
								<!--begin::Header Logo-->
								<div class="header-logo">
									<!-- <a href="javascript:;">
                                        <img alt="Logo" src="{{ asset('media/logos/logo-p2ep.png') }}" width="70px"/>
									</a> -->
									
									<h3 class="ml-5 mt-3"> P2EP | HOP PLTU</h3>
								</div>
								<!--end::Header Logo-->
								
								
							</div>
							<!--end::Header Menu Wrapper-->
							<h3 class="mt-7 text-center"><a href="https://p2ep.plnepi.co.id/" target="_blank" class="text-dark">SmartSys</a> | <a href="{{ route('under.scheduler') }}" target="_blank" class="text-dark">Scheduler</a></h3>
							<!--begin::Topbar-->
							<div class="topbar">
								
								
								<div class="topbar-item">

									<!--begin::Quick Actions-->
									<div class="dropdown">
										<!--begin::Toggle-->
										<div class="topbar-item" data-toggle="dropdown" data-offset="10px,0px">
										<span class="text-dark-50 font-weight-bolder font-size-base d-none d-md-inline mr-3" style="cursor:pointer"> <span id="show_date"></span></span>
											<div class="btn btn-icon btn-clean btn-dropdown btn-lg mr-1">
											<span class="svg-icon svg-icon-xl svg-icon-primary">
												<!--begin::Svg Icon | path:assets/media/svg/icons/General/Search.svg-->
												<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
													<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
														<rect x="0" y="0" width="24" height="24" />
														<path d="M14.2928932,16.7071068 C13.9023689,16.3165825 13.9023689,15.6834175 14.2928932,15.2928932 C14.6834175,14.9023689 15.3165825,14.9023689 15.7071068,15.2928932 L19.7071068,19.2928932 C20.0976311,19.6834175 20.0976311,20.3165825 19.7071068,20.7071068 C19.3165825,21.0976311 18.6834175,21.0976311 18.2928932,20.7071068 L14.2928932,16.7071068 Z" fill="#000000" fill-rule="nonzero" opacity="0.3" />
														<path d="M11,16 C13.7614237,16 16,13.7614237 16,11 C16,8.23857625 13.7614237,6 11,6 C8.23857625,6 6,8.23857625 6,11 C6,13.7614237 8.23857625,16 11,16 Z M11,18 C7.13400675,18 4,14.8659932 4,11 C4,7.13400675 7.13400675,4 11,4 C14.8659932,4 18,7.13400675 18,11 C18,14.8659932 14.8659932,18 11,18 Z" fill="#000000" fill-rule="nonzero" />
													</g>
												</svg>
												<!--end::Svg Icon-->
											</span>
											</div>
										</div>
										<!--end::Toggle-->
										<!--begin::Dropdown-->
										<div class="dropdown-menu p-0 m-0 dropdown-menu-right dropdown-menu-anim-up dropdown-menu-lg">
											
											<div class="d-flex flex-column flex-center ml-8 mr-8 py-10 bgi-size-cover bgi-no-repeat rounded-top">
												<form action="javascript:;" method="post" id="form-filter" enctype="multipart/form-data">
													<!-- <div class="form-group row">
														<label class="col-sm-12 col-form-label">Tanggal <span class="text-danger">*</span></label>
														<div class="col-sm-12">
															<input name="tanggal" id="tanggal" type="date" class="form-control" value="{{date('Y-m-d')}}">
														</div>
													</div>	 -->
													<div class="form-group row">
														<!-- <label class="col-sm-12 col-form-label">Outline Default</label> -->
														<div class="col-sm-12 col-form-label">
															<div class="radio-inline">
																<label class="radio radio-outline radio-success filter_type">
																<input type="radio" name="filter_type" value="daily" checked="checked"/>
																<span></span>Harian</label>
																<label class="radio radio-outline radio-success filter_type">
																<input type="radio" name="filter_type" value="monthly" />
																<span></span>Bulanan (rata-rata)</label>
																
															</div>
														</div>
													</div>
													<div class="form-group row filter_field_date">
														<div class="col-sm-12">
										
															<div class="input-group date">
																<input type="text" class="form-control input-sm  show_date_picker" name="filter_date" id="filter_date" value="{{date('Y-m-d')}}" placeholder="Select date ......" />
																<div class="input-group-append">
																	<span class="input-group-text">
																		<i class="la la-calendar-check-o"></i>
																	</span>
																</div>
															</div>
														</div>
													</div>
													<div class="form-group row display-none filter_field_month">
														<div class="col-sm-12">
															
															<div class="input-group date">
																<input type="text" class="form-control input-sm  filter_month" name="filter_month" id="filter_month" placeholder="Select month ......" />
																<div class="input-group-append">
																	<span class="input-group-text">
																		<i class="la la-calendar-check-o"></i>
																	</span>
																</div>
															</div>
														</div>
													</div>
												</form>
											</div>
											
											
										</div>
										<!--end::Dropdown-->
									</div>
									<!--end::Quick Actions-->
									
								</div>
								
								<!--begin::User-->
								<div class="dropdown" >
									<div class="topbar-item">
										<div class="btn btn-icon btn-icon-mobile w-auto btn-clean d-flex align-items-center btn-lg px-2" id="kt_quick_user_toggle">
											<span class="text-muted font-weight-bold font-size-base d-none d-md-inline mr-1">Hi,</span>
											<span class="text-dark-50 font-weight-bolder font-size-base d-none d-md-inline mr-3">{{ Auth::user()->name }}</span>
											<span class="symbol symbol-lg-35 symbol-25 symbol-light-success">
												<form method="POST" action="{{ route('logout') }}">
													@csrf
													<x-responsive-nav-link style="margin-left:-9px;" :href="route('logout')"
															onclick="event.preventDefault();
																		this.closest('form').submit();">
														<span class="symbol-label font-size-h5 font-weight-bold"><img src="{{ asset('media/svg/icons/Navigation/Sign-out.svg')}}"/></span>
													</x-responsive-nav-link>
												</form>
											
											</span>
										</div>
									</div>
								</div>
								<!--end::User-->
								
								
							</div>
							<!--end::Topbar-->
						</div>
						<!--end::Container-->
					</div>
					<!--end::Header-->